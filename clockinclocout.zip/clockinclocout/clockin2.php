<?php
$con=mysqli_connect("localhost","root","","clock");
$select=mysqli_query($con,"SELECT * FROM clockin WHERE function='clockin' AND function2='clockout' AND id='1'");
if(mysqli_num_rows($select)>0){
    while($row=mysqli_fetch_array($select)){
        ?>
        <form>
        <p style="color:red;">You already Clocked In</p><br />
        <input type="submit" value="Clockin" disabled="" /><br />
        <p style="color:red;">You already Clocked Out</p><br />
        <input type="submit" value="Clockout" disabled="" />
        </form>
        <?php
    }
}else{
    


?>



<?php
$con=mysqli_connect("localhost","root","","clock");
$select=mysqli_query($con,"SELECT * FROM clockin WHERE function='clockin' AND id='1'");
if(mysqli_num_rows($select)>0){
    while($row=mysqli_fetch_array($select)){?>
       <form method="POST">
    <input type="submit" value="Clock Out" name="clockout"/>
    <?php
    
    $con=mysqli_connect("localhost","root","","clock");
if(isset($_POST['clockout'])){
    $date=date('Y-m-d');
$update=mysqli_query($con,"UPDATE clockin SET function2='clockout',date2='$date' WHERE id='1'");
$update=mysqli_query($con,"UPDATE clockout SET date='$date' WHERE id='3'");
if($update ){
    ?> <script type="text/javascript">
		    alert("You Have cloked Out.");
		    window.location = "clockin2.php";
		</script><?php
}else{
    echo"error";
}
}
    
    ?>
    </form> 
  <?php  }
}else{
    ?>
    <form method="POST">
    <input type="submit" value="Clock  in" name="clockin"/>
    <?php
    
    $con=mysqli_connect("localhost","root","","clock");
if(isset($_POST['clockin'])){
    $date=date('Y-m-d');
$update=mysqli_query($con,"UPDATE clockin SET function='clockin',date='$date' WHERE id='1'");
date_default_timezone_set("Africa/Lagos");
$time= date("h:i:sa");
$insert=mysqli_query($con,"INSERT INTO clockout (time) VALUES ('$time')");

if($update ){
    ?> <script type="text/javascript">
		    alert("You Have cloked In.");
		    window.location = "clockin2.php";
		</script><?php
}else{
    echo"error";
}
}
    
    ?>
    </form>
    <?php
}
}
?>
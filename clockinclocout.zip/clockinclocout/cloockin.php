<?php 
$con=mysqli_connect("localhost","root","","clock");
$select=mysqli_query($con,"SELECT * FROM clockin WHERE function='clockin' AND id='1'");


if(mysqli_num_rows($select)>0){
    while($row=mysqli_fetch_array($select)){?>
    <form method="POST">
    <p style="color:red;">You already Clocked in</p>
<input type="submit" value="Clock in" name="clockin" disabled=""/>
</form>
    <?php } 
}else{
    ?> <form method="POST">
<input type="submit" value="Clock In" name="clockin"/>
</form>
<?php 
}
?>





<?php
$con=mysqli_connect("localhost","root","","clock");
if(isset($_POST['clockin'])){
    $date=date('Y-m-d');
$update=mysqli_query($con,"UPDATE clockin SET function='clockin',date='$date' WHERE id='1'");
if($update ){
    ?> <script type="text/javascript">
		    alert("You Have cloked in.");
		    window.location = "cloockin.php";
		</script><?php
}else{
    echo"error";
}
}

?>
<?php 
$con=mysqli_connect("localhost","root","","clock");
$select=mysqli_query($con,"SELECT * FROM clockout WHERE function='clockout' AND id='1'");

if(mysqli_num_rows($select)>0){
    while($row=mysqli_fetch_array($select)){?>
    <form method="POST">
    <p style="color:red;">You already Clocked out</p>
<input type="submit" value="Clock Out" name="clockout" disabled=""/>
</form>
    <?php } 
}else{
    ?> <form method="POST">
<input type="submit" value="Clock Out" name="clockout"/>
</form>
<?php 
}
?>




<?php
$con=mysqli_connect("localhost","root","","clock");
if(isset($_POST['clockout'])){
    $date=date('Y-m-d');
$update=mysqli_query($con,"UPDATE clockout SET function='clockout',date='$date' WHERE id='1'");
if($update ){
    ?>
    <script type="text/javascript">
		    alert("You Haved Clocked out.");
		    window.location = "cloockin.php";
		</script>
    <?php
}else{
    echo"error";
}
}

?>





</html>